#!/usr/bin/env bash
set -euo pipefail
cd /mnt/data/ypk/Projects/Inpaint360GS
while kill -0 3804065 2>/dev/null; do sleep 2; done
[ -f output/mvp-resource-replay-20261013/STATUS ]
bash output/mvp-resource-replay-20261013/repair/run.sh
