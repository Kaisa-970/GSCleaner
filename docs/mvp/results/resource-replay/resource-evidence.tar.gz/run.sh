#!/usr/bin/env bash
set -euo pipefail
cd /mnt/data/ypk/Projects/Inpaint360GS
source env.sh
TASK_REPLAY="$PWD/output/mvp-resource-replay-20261013"
python /tmp/measure_step.py --output "$TASK_REPLAY/training-resource.json" -- python gaussian_splatting/train.py -s data/inpaint360/toys -m "$TASK_REPLAY/3dgs_output" --init_mode sparse --eval --resolution 8 --iterations 1000 --save_iterations 1000 --test_iterations 1000 > "$TASK_REPLAY/train.log" 2>&1
python /tmp/measure_step.py --output "$TASK_REPLAY/deletion-resource.json" -- python /tmp/export_removal.py --repo "$PWD" --checkpoint "$PWD/output/mvp-toys-20261013/model/point_cloud/iteration_2000/point_cloud.ply" --classifier "$PWD/output/mvp-toys-20261013/model/point_cloud/iteration_2000/classifier.pth" --reference "$PWD/output/mvp-toys-20261013/removal/point_cloud_object_removal/iteration_2000/point_cloud.ply" --output "$TASK_REPLAY/removal" --ids 23 28 27 > "$TASK_REPLAY/removal.log" 2>&1
printf 'TRAIN_DELETE_COMPLETE\n' > "$TASK_REPLAY/STATUS"
