#!/usr/bin/env bash
INPAINT360_ROOT=/mnt/data/ypk/Projects/Inpaint360GS
export CUDA_HOME=/usr/local/cuda-12.8
export PATH="$INPAINT360_ROOT/.venv/bin:$CUDA_HOME/bin:$PATH"
export PYTHONPATH="$INPAINT360_ROOT:$INPAINT360_ROOT/seg/detectron2:$INPAINT360_ROOT/seg/detectron2/detectron2/projects/CropFormer${PYTHONPATH:+:$PYTHONPATH}"
export TORCH_CUDA_ARCH_LIST=8.6
export MAX_JOBS=4
export WANDB_MODE=disabled
